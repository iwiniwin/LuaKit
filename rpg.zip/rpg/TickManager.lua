
local TickManager = {};

function TickManager:ctor()
	self.ticks = {};
end

function TickManager:add(func)
	if type(func) == "function" then
		table.insert(self.ticks,func);
	end
end


return TickManager;