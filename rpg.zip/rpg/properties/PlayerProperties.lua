local PlayerProperties = {}

local defines = {}

local player = {
    id          = "Player001";
    name        = "裸男";
    status      = 0; --状态
    maxHP       = 3000; --最大生命值
    attackSpeed = 1.1; -- 攻击速度
    attack      = 100; --攻击力
    defense     = 40; -- 防御力
    missRate    = 0; --闪避概率
    critical    = 0; --暴击概率
    skill       = {{id = 1001,level = 1}} --技能
}
defines[player.id] = player



local player = {
    id          = "Player002";
    name        = "杨健";
    status      = 0;        --状态
    maxHP       = 3600;     --最大生命值
    attackSpeed = 1.4;      -- 攻击速度
    attack      = 100;      --攻击力
    defense     = 55;       -- 防御力
    missRate    = 0;       --闪避概率
    critical    = 0;        --暴击概率
    skill       = {{id = 1002,level = 1},{id = 1004,level = 1}}; --技能
}
defines[player.id] = player


local player = {
    id          = "Player003";
    name        = "梦丹";
    status      = 0;        --状态
    maxHP       = 1700;     --最大生命值
    attackSpeed = 1;      -- 攻击速度
    attack      = 115;      --攻击力
    defense     = 35;       -- 防御力
    missRate    = 0;        --闪避概率
    critical    = 0;        --暴击概率
    skill       = {{id = 1003,level = 1}}; --技能
}
defines[player.id] = player


local player = {
    id          = "Player004";
    name        = "包子";
    status      = 0;        --状态
    maxHP       = 2700;     --最大生命值
    attackSpeed = 1.5;      -- 攻击速度
    attack      = 95;      --攻击力
    defense     = 60;       -- 防御力
    missRate    = 0;        --闪避概率
    critical    = 0;        --暴击概率
    skill       = {{id = 1003,level = 1}}; --技能
}
defines[player.id] = player


local player = {
    id          = "Player005";
    name        = "紫玉";
    status      = 0;        --状态
    maxHP       = 1700;     --最大生命值
    attackSpeed = 1;      -- 攻击速度
    attack      = 115;      --攻击力
    defense     = 30;       -- 防御力
    missRate    = 0;        --闪避概率
    critical    = 0;        --暴击概率
    skill       = {{id = 1006,level = 10},{id = 1007,level = 10}}; --技能
}
defines[player.id] = player


local player = {
    id          = "Player006";
    name        = "浩然";
    status      = 0;        --状态
    maxHP       = 2100;     --最大生命值
    attackSpeed = 0.8;      -- 攻击速度
    attack      = 135;      --攻击力
    defense     = 30;       -- 防御力
    missRate    = 0;        --闪避概率
    critical    = 0;        --暴击概率
    skill       = {{id = 1005,level = 1}}; --技能
}
defines[player.id] = player




function PlayerProperties.get(id)
    if defines[id] then
        return clone(defines[id])
    end
    for k,v in pairs(defines) do
        if v.id == id or v.name == id then
            return clone(defines[k])
        end
    end

end

return PlayerProperties
