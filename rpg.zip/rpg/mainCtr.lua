
local function mainCtr()
	

	local function update(dt)
		print("1",dt)
	end
	g_TickManager:add(update);
end


mainCtr();