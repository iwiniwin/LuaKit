

local print = print;

local Log = {}

local file = nil
function Log.init()
	os.remove("log.txt")
	file = io.open("log.txt", "a+")
	file:setvbuf ("line")
end

function Log.print(...)
	print(...);

	local args = {...}
	table.insert(args,g_Tick);
	local ret = table.concat(args, "    ");
	file:write(ret)
	file:write("\n")
	file:flush();
end

function Log.close( ... )
	file:close();
	file = nil
end

return Log;