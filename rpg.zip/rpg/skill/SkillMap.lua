

--[[
skillCount 攻击次数 如攻击4次 触发一次技能
cooldown 冷却次数，比如释放技能之后，需要冷却5次攻击时间 然后再触发技能
]]
local SkillMap = {};

---
SkillMap[1001] = {behavior = "BloodSkill",name = "血之献祭",skillData = {skillCount = 4,cooldown = 5,buffID = {},damage = 100},lvup = {}};

SkillMap[1002] = {behavior = "Stun",name = "眩晕3秒",skillData = {skillCount = 4,cooldown = 5,buffID = {},damage = 200},lvup = {}};

SkillMap[1003] = {behavior = "SingleSkill",name = "泰山压顶",skillData = {skillCount = 4,cooldown = 5,damage = {key = "attack",scale = 3,add = 100}},lvup = {}};

SkillMap[1004] = {behavior = "SingleSkill",name = "背水一战",skillData = {skillCount = 9,cooldown = 9,damage = {key = "defense",scale = 5,add = 70}},lvup = {}};

SkillMap[1005] = {behavior = "MissSkill",name = "模糊",skillData = {missRate = 15},lvup = {add = 1}};


SkillMap[1006] = {behavior = "CriticalSkill",name = "致命一击",skillData = {critical = 15,scale = 2.4},lvup = {add = 0.5}};

SkillMap[1007] = {behavior = "HealthSkill",name = "春风化物",skillData = {skillCount = 4,cooldown = 5,damage = {key = "attack",scale = 3,add = 50}},lvup = {add = 5}};


return SkillMap;