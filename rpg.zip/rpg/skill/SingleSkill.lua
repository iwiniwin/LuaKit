local SkillBase = import(".SkillBase");
---流血debuff
local SingleSkill = class(SkillBase,false);

function SingleSkill:ctor(params)
	SingleSkill.super.ctor(self, "SingleSkill", nil, 1);
	self:init(params);
end

function SingleSkill:doSkill(obj,targets)
	local enemy = nil
	for i,v in ipairs(targets) do
		if v:isDead() == false then
			enemy = targets[i];
			break;
		end
	end
	if enemy == nil then
		return;
	end
	
	local damage = 0;
	if type(self.skill_.skillData.damage) == "table" then
		local data = self.skill_.skillData.damage;
		if data.key and data.scale then
			damage = damage + enemy[data.key] * data.scale
		end
		if data.add then
			damage = damage + data.add;
		end
		
		enemy:updateHP(damage);
	end

	print(string.format("%s 向 %s 释放 %s 造成%s点伤害",obj.name,enemy.name , self.name_,damage))

	if enemy:isDead() then
		print(string.format("%s 杀死 %s ",self.obj_.name,enemy.name));
	end

end


function SingleSkill:bind(obj)
	SingleSkill.super.bind(self, obj);
	self.obj_ = obj;
	obj:bindMethod(self, "doSkill", handler(self,self.doSkill))
end

function SingleSkill:unBind(obj)
	SingleSkill.super.unBind(self, obj);
	obj:unBindMethod(self, "doSkill");
	self.obj_ = nil;
end

return SingleSkill;