
---暴击
local CriticalSkill = class(BehaviorBase,false);

function CriticalSkill:ctor(params)
	CriticalSkill.super.ctor(self, "CriticalSkill", nil, 1);
	self.skill_ = params;
	-- dump(params)
end

function CriticalSkill:bind(obj)
	
	local critical = self.skill_.skillData.critical
	local scale = self.skill_.skillData.scale;
	if self.skill_.lvup and self.skill_.level then
		critical = critical + self.skill_.lvup.add * (self.skill_.level - 1)
		scale    = scale + (self.skill_.lvup.add * (self.skill_.level - 1) * 0.08)
	end

	print(string.format("%s 拥有 %s 提升 %s%% 暴击率,暴击伤害提高%s倍",
		obj.name,self.skill_.name,critical,scale))

	obj.critical = critical

	self.scale = scale;
end

function CriticalSkill:getCriticalDamage(damage)
	local d = self.scale * damage
	return d;
end

function CriticalSkill:unBind(obj)
	obj.critical = 0;

end

return CriticalSkill;