local AttackBehavior = class(BehaviorBase,false)

function AttackBehavior:ctor( ... )
	AttackBehavior.super.ctor(self, "攻击组件", nil, 1);
	self.attackCount = 0;
	self:attackEnable(nil,true);
end

function AttackBehavior:tick(obj,dt)

	if  self:isAttackEnable(obj) ~= true then
		return;
	end
	
	if not self.cooldown then --攻击冷却时间
		self.cooldown = obj.attackSpeed;
	end
	self.cooldown = self.cooldown - dt;
	if self.cooldown <= 0 then
		self.cooldown = nil;
		if self.attackTarget then
			self:attackTarget()
		end
	end
end

function AttackBehavior:attackEnable(obj,enable)
	self.enable = enable;
	if enable == false then
		self:resetAttack(obj);
	end
end

function AttackBehavior:isAttackEnable(obj,enable)
	return self.enable;
end



function AttackBehavior:resetAttack(obj)
	self.cooldown = obj.attackSpeed;

end

function AttackBehavior:attackTarget()
	local camp = self.obj_.camp + 1;
	if camp > #gameObjectList then
		camp = 1;
	end

	local target = gameObjectList[camp];
	target = checktable(target);

	if  self.obj_.checkSkill and self.obj_:checkSkill(target) == true then
		return;
	end

	local enemy = nil
	for i,v in ipairs(target) do
		if v.hp > 0 then
			enemy = target[i];
			break;
		end
	end

	if not enemy then
		return;
	end

	self.attackCount = self.attackCount + 1;

	if self:isHit(enemy) == false then
		print(string.format("%s 攻击 %s 没有命中",self.obj_.name,enemy.name));
		return;
	end

	local damage = self.obj_.attack - enemy.defense; --伤害
	if self:isCritical() == true then
		if self.obj_:hasBehavior("CriticalSkill") then
			damage = self.obj_:getBehavior("CriticalSkill"):getCriticalDamage(damage)
		end
		enemy:updateHP(damage);
		print(string.format("%s 攻击 %s 触发暴击造成%s点伤害 %s 剩余生命值: %s/%s",self.obj_.name,enemy.name,damage,enemy.name,enemy.hp,enemy.maxHP));
	else
		enemy:updateHP(damage);
		print(string.format("%s 攻击 %s 造成%s点伤害 %s 剩余生命值: %s/%s",self.obj_.name,enemy.name,damage,enemy.name,enemy.hp,enemy.maxHP));
	end

	if enemy:isDead() then
		print(string.format("%s 杀死 %s ",self.obj_.name,enemy.name));
	end
	


end

function AttackBehavior:isHit(target)
	local missRate = target.missRate;
	if missRate then
		return math.random(1,100) >= missRate;
	end
	return false;
end

function AttackBehavior:isCritical()
	local critical = self.obj_.critical;
	if critical then
		return math.random(1,100) <= critical;
	end
	return false;
end


function AttackBehavior:bind(obj)
	self.obj_ = obj;
	obj:bindMethod(self, "tick", handler(self,self.tick))
	obj:bindMethod(self, "attackEnable", handler(self,self.attackEnable))
	obj:bindMethod(self, "isAttackEnable", handler(self,self.isAttackEnable))
end

function AttackBehavior:unBind( ... )
	obj:unBindMethod(self, "tick");
	obj:unBindMethod(self, "attackEnable")
	obj:unBindMethod(self, "isAttackEnable")
	self.obj_ = nil;
end

return AttackBehavior;