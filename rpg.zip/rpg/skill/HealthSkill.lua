local SkillBase = import(".SkillBase");

---回复生命值
local HealthSkill = class(SkillBase,false);

function HealthSkill:ctor(params)
	HealthSkill.super.ctor(self, "春雨化物", nil, 1);
	self:init(params);
end

function HealthSkill:doSkill(obj,targets)
	local myTeam = gameObjectList[obj.camp];
	myTeam = checktable(myTeam);

	local target = nil;
	for i,v in ipairs(myTeam) do
		if v:isDead() == false then
			target = v;
		end
		if target and v:isDead() == false and (v.maxHP - v.hp) < (target.maxHP - target.hp) then
			target = myTeam[i]
		end
	end
	if target == nil then
		return;
	end

	local damage = 0;
	if type(self.skill_.skillData.damage) == "table" then
		local data = self.skill_.skillData.damage;





		if data.key and data.scale then
			local scale = data.scale;
			scale   = scale + (self.skill_.lvup.add * (self.skill_.level - 1) * 0.01)
			damage = damage + target[data.key] * data.scale
		end
		if data.add then
			local add = data.add;
			add   = add + (self.skill_.lvup.add * (self.skill_.level - 1) * 2)
			damage = damage + add;
		end
		
		damage = damage * -1;
		target:updateHP(damage);

		print(string.format("%s 向 %s 释放 %s 回复%s点生命值, %s 当前生命值为 %s",
			obj.name,target.name , self.name_,damage*-1,target.name,target.hp))

	end

end


function HealthSkill:bind(obj)
	
	HealthSkill.super.bind(self, obj);
	self.obj_ = obj;
	obj:bindMethod(self, "doSkill", handler(self,self.doSkill))
end

function HealthSkill:unBind(obj)
	HealthSkill.super.unBind(self, obj);
	obj:unBindMethod(self, "doSkill");
	self.obj_ = nil;
end

return HealthSkill;