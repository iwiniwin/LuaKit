
---闪避
local MissSkill = class(BehaviorBase,false);

function MissSkill:ctor(params)
	MissSkill.super.ctor(self, "MissSkill", nil, 1);
	self.skill_ = params;


end

function MissSkill:bind(obj)
	
	local missRate = self.skill_.skillData.missRate
	if self.skill_.lvup and self.skill_.level then
		missRate = missRate + self.skill_.lvup.add * (self.skill_.level - 1)
	end

	print(string.format("%s 拥有 %s 提高 %s 点闪避",
		obj.name,self.skill_.name,missRate))
	obj.missRate = missRate
end

function MissSkill:unBind(obj)
	obj.missRate = 0;

end

return MissSkill;