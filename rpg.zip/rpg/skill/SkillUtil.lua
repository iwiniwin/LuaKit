local SkillMap = import(".SkillMap")

local SkillUtil = {};


function SkillUtil.initSkill(obj)
	if obj.skill and type(obj.skill) == "table" then
		for i,v in ipairs(obj.skill) do
			local skill = clone(SkillMap[v.id]);
			if skill then
				skill.level = v.level
				skill.skillID = v.id;
				-- dump(skillData)
				if skill.behavior then
					obj:bindBehavior(skill.behavior,skill);
				end
			end
			-- dump(skill)
		end
	end
end

return SkillUtil;