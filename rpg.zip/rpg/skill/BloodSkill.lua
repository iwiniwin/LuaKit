local SkillBase = import(".SkillBase");
---流血debuff
local BloodSkill = class(SkillBase,false);

function BloodSkill:ctor(params)
	BloodSkill.super.ctor(self, "血之祭祀", nil, 1);
	self:init(params);
end

function BloodSkill:doSkill(obj,targets)
	local enemy = nil
	for i,v in ipairs(targets) do
		if v.hp > 0 then
			enemy = targets[i];
			break;
		end
	end
	if enemy and enemy:hasBehavior("BloodDebuff")  == true then
		enemy:unBindBehavior("BloodDebuff");
	end

	enemy:bindBehavior("BloodDebuff")
	enemy:updateHP(self.skill_.skillData.damage);
	local BloodDebuff = enemy:getBehavior("BloodDebuff");
	print(string.format("%s 释放 %s 造成%s点伤害，并附带流血debuff，每秒造成%s点伤害",
		obj.name,self.name_,self.skill_.skillData.damage,BloodDebuff.damage))

	if enemy:isDead() then
		print(string.format("%s 杀死 %s ",self.obj_.name,enemy.name));
	end

end


function BloodSkill:bind(obj)
	BloodSkill.super.bind(self, obj);
	self.obj_ = obj;
	obj:bindMethod(self, "doSkill", handler(self,self.doSkill))
end

function BloodSkill:unBind(obj)
	BloodSkill.super.unBind(self, obj);
	obj:unBindMethod(self, "doSkill");
	self.obj_ = nil;
end

return BloodSkill;