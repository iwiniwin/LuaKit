local AttackBehavior = import(".AttackBehavior");

local BloodSkill 		= import(".BloodSkill");
local Stun = import(".Stun");
local SingleSkill 		= import(".SingleSkill");
local MissSkill   		= import(".MissSkill");
local CriticalSkill   	= import(".CriticalSkill");

local HealthSkill   	= import(".HealthSkill");




local BehaviorMap = {}

BehaviorMap.BloodSkill 			= BloodSkill;
BehaviorMap.Stun 				= Stun;
BehaviorMap.SingleSkill 		= SingleSkill;
BehaviorMap.MissSkill 			= MissSkill;
BehaviorMap.CriticalSkill 		= CriticalSkill;

BehaviorMap.HealthSkill 		= HealthSkill;

BehaviorMap.AttackBehavior  = AttackBehavior;



BehaviorFactory.combineBehaviorsClass(BehaviorMap);


return BehaviorMap;