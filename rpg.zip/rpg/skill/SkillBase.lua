local SkillBase = class(BehaviorBase,false)

function SkillBase:ctor(behaviorName, depends, priority)
	SkillBase.super.ctor(self, behaviorName, depends, priority);
	self.count = 0;
	self.skillCount = 0; --攻击多少次 施法一次
	self.cooldown   = 0; --冷却时间

end

function SkillBase:init(params)
	local params = checktable(params)
	if params.skillData and params.skillData.skillCount then
		self.skillCount = params.skillData.skillCount ;
	end
	if params.skillData and params.skillData.cooldown then
		self.cooldown = params.skillData.cooldown ;
	end
	if params.name  then
		self.name_ = params.name;
	end
	self.skill_ = params;
end

function SkillBase:checkSkill(obj,targets,...)
	local args = {...}
	if args then
		if args[#args] == true then
			return true;
		end
	end

	self.count = self.count + 1;
	if self.count == self.skillCount then
		self:doSkill(obj,targets)
		return true;
	end

	if self.count ==  self.cooldown + self.skillCount then
		self.count = 0;
	end
	return false;
end

function SkillBase:doSkill(obj,targets)

end


function SkillBase:bind(obj)
	obj:bindMethod(self, "checkSkill", handler(self,self.checkSkill))
end

function SkillBase:unBind(obj)
	obj:unBindMethod(self, "checkSkill");
end

return SkillBase;