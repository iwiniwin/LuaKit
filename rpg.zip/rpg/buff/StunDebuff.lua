
---眩晕
local StunDebuff = class(BehaviorBase,false)

function StunDebuff:ctor()
	StunDebuff.super.ctor(self, "眩晕debuff", nil, 1);
	self.time = 3;-- 持续时间
end

function StunDebuff:tick(obj,dt)
	self.time = self.time - dt;
	if self.time <= 0 then
		obj:unBindBehavior("StunDebuff")
		if obj.attackEnable then
			obj:attackEnable(true); --允许攻击
		end

	end
end

function StunDebuff:bind(obj)
	if obj.attackEnable then
		obj:attackEnable(false); --禁止攻击
	end
	obj:bindMethod(self, "tick", handler(self,self.tick))
end

function StunDebuff:unBind(obj)
	obj:unBindMethod(self, "tick");
end

return StunDebuff;