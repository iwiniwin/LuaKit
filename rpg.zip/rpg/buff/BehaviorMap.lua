local BloodDebuff = import(".BloodDebuff");
local StunDebuff = import(".StunDebuff");
local BehaviorMap = {}

BehaviorMap.BloodDebuff = BloodDebuff;
BehaviorMap.StunDebuff = StunDebuff;



BehaviorFactory.combineBehaviorsClass(BehaviorMap);


return BehaviorMap;