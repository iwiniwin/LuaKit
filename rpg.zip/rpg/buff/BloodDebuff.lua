
---流血debuff
local BloodDebuff = class(BehaviorBase,false)

function BloodDebuff:ctor()
	BloodDebuff.super.ctor(self, "流血", nil, 1);
	self.bloodCooldown = 0;
	self.damage = 30;
	self.bloodTime = 10;-- 持续时间
end

function BloodDebuff:tick(obj,dt)
	self.bloodCooldown = self.bloodCooldown + dt;
	if self.bloodCooldown >= 1 then
		self.bloodCooldown = 0;
		obj:updateHP(self.damage)
	end

	self.bloodTime = self.bloodTime - dt;

	if self.bloodTime <= 0 then
		if obj.onBuffFinish then
			obj:onBuffFinish()
		end
		obj:unBindBehavior("BloodDebuff")
	end
end

function BloodDebuff:bind(obj)
	self.obj_ = obj;
	obj:bindMethod(self, "tick", handler(self,self.tick))
end

function BloodDebuff:unBind(obj)
	obj:unBindMethod(self, "tick");
	self.obj_ = nil;
end

return BloodDebuff;