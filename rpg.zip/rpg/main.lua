--[[--ldoc desc
@module main
@author YuchengMo

Date   2018-07-02 10:17:46
Last Modified by   YuchengMo
Last Modified time 2018-07-05 18:29:19
]]
require("LuaKit._load")
local TickManager = require("TickManager")
g_TickManager = new(TickManager);

local socket = require("socket");
-- dump(socket)
local maxTick = 10000;
local start_,end_,dt = 0,0,0

g_isGameOver = false;

g_Tick = 0;

function update(dt,tick)
    local ticks = g_TickManager.ticks;
    for i,v in ipairs(ticks) do
        v(dt)
    end
end

---主入口 控制主循环
local function main()

    -- print("1",os.clock())
    local Log = require("Log");

    Log:init();
    print = Log.print
    dump = require("LuaKit/framework/tools/dump");--为了让dunm 也写文件


    start_ = os.clock();
    mainCtr()
    end_   = os.clock();
    dt =  1/60;
    dt = string.format("%.3f", dt)
    while g_isGameOver == false do
        g_Tick = g_Tick + 1;
        if maxTick < g_Tick then
            break;
        end
        start_ = os.clock();
        update(dt,g_Tick)
        -- socket.sleep(1/60)
        end_   = os.clock();
        dt = end_ - start_;
        if dt < 1/60 then
            dt = 1/60
        end
    end

    
    for i,arr in ipairs(gameObjectList) do
        local list = {}
    	for i,v in ipairs(arr) do
    		local p = {};
	    	p.hp = v.hp;
	    	p.name = v.name;
	    	table.insert(list,p)
    	end
        dump(list)
    end
   

    Log:close();

end

local GameObject = class(BehaviorBase)


local playerList = {};

local enemyList  = {};

local Player = {
}
BehaviorExtend(Player);

function Player:ctor(args)
	args = checktable(args);
	table.merge(self,args);
	self.hp = self.maxHP;
end

gameObjectList = {};

table.insert(gameObjectList,playerList)
table.insert(gameObjectList,enemyList)


require("skill.BehaviorMap")
require("buff.BehaviorMap")
require("components.BehaviorMap")
local SkillUtil = require("skill.SkillUtil")
local PlayerProperties = require("properties/PlayerProperties")

function mainCtr( )

    local baseDepends = {"HPBehavior","AttackBehavior"}
	math.newrandomseed();

    local players = {"Player001","Player004","Player003"}
    for i,v in ipairs(players) do
        local p = new(Player,PlayerProperties.get(v));
        p.camp = 1;
        for i,v in ipairs(baseDepends) do
           p:bindBehavior(v)
        end
        SkillUtil.initSkill(p)
        table.insert(playerList,p);
    end

    local enemys   = {"Player002","Player006","Player005"}
    for i,v in ipairs(enemys) do
        local e = new(Player,PlayerProperties.get(v));
        e.camp = 2;
        for i,v in ipairs(baseDepends) do
           e:bindBehavior(v)
        end
        SkillUtil.initSkill(e)
        table.insert(enemyList,e);
    end


    local function update(dt)

    	for i,list in ipairs(gameObjectList) do
    		local deadNum = 0;
    		for i,v in ipairs(list) do
    			if v:isDead() then
    				deadNum = deadNum + 1;
    			end
    		end
    		if deadNum == #list then
    			g_isGameOver = true;
    			return;
    		end
    	end

    	for i,list in ipairs(gameObjectList) do
    		for i,p in ipairs(list) do
    			if p.tick then
    				p:tick(dt)
    			end
    		end
    	end

    end

    g_TickManager:add(update);

end


main()