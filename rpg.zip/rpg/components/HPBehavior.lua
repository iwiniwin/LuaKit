local HPBehavior = class(BehaviorBase,false)

function HPBehavior:ctor()
	HPBehavior.super.ctor(self, "生命组件", nil, 1);
end

function HPBehavior:isDead(self)
	return self.hp <= 0;
end

function HPBehavior:updateHP(self,damage)
	self.hp = self.hp - damage;
	if self.hp < 0 then
		self.hp = 0;
	end
	if self.hp > self.maxHP then
		self.hp = self.maxHP
	end
end

function HPBehavior:bind(obj)
	obj:bindMethod(self, "isDead", handler(self,self.isDead))
	obj:bindMethod(self, "updateHP", handler(self,self.updateHP))
end

function HPBehavior:unBind( ... )
	obj:unBindMethod(self, "isDead")
	obj:unBindMethod(self, "updateHP")
end

return HPBehavior;