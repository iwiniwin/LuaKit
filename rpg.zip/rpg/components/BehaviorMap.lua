local HPBehavior = import(".HPBehavior");

local BehaviorMap = {}

BehaviorMap.HPBehavior 		= HPBehavior;

BehaviorFactory.combineBehaviorsClass(BehaviorMap);


return BehaviorMap;