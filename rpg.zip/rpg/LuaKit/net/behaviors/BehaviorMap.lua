--[[--ldoc desc
@module BehaviorMap
@author YuchengMo

Date   2018-04-04 17:16:38
Last Modified by   YuchengMo
Last Modified time 2018-04-25 15:04:33
]]



local BehaviorMap = {
   

}

BehaviorFactory.combineBehaviorsClass(BehaviorMap);

return BehaviorMap
