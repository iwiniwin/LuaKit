--[[--组件配置文件
@module BehaviorConfig
@author YuchengMo

Date   2017-12-20 16:12:01
Last Modified by   YuchengMo
Last Modified time 2017-12-27 11:22:12
]]

local BehaviorConfig = {}

---根据类名配置组件
BehaviorConfig.className = {
	-- "TestBehavior",--测试组件
}



return BehaviorConfig;
